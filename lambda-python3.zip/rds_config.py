#config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "password"
db_name = "test"